# app
Exercice = new Exercice() 
  app2.style.visibility = "hidden";
  acce.style.visibility = "visible";
  document.body.style.backgroundImage = "url('/e5/yoga-routine/cours/img/images.png')"
acce.style.visibility = "visible";
    app2.style.visibility = "hidden ";